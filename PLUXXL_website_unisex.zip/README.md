# PLUXXL — Inclusive Big Size Fashion

Bản demo website thương mại điện tử cho PLUXXL, phục vụ thời trang Big Size cho cả nam và nữ, bao gồm suit/vest, sơ mi, váy và trang phục dự tiệc và dịch vụ mua/thuê.

## Chạy website
- Mở `index.html` bằng trình duyệt.
- Trang quản trị: `admin.html`.

## Chức năng
- Trang chủ responsive
- Danh mục và lọc sản phẩm
- Tìm kiếm
- Chi tiết sản phẩm
- Chọn size
- Mua / thuê
- Chọn ngày thuê
- Giỏ hàng
- Checkout
- Lịch sử đơn hàng
- Đăng nhập/đăng ký demo
- Wishlist
- Size Guide
- Newsletter
- Admin dashboard demo
- Lưu dữ liệu demo bằng localStorage

## Lưu ý
Đây là bản frontend/demo chạy độc lập, chưa có backend, database thật, tài khoản thật hoặc cổng thanh toán thật. Có thể nâng cấp tiếp sang Java Servlet/JSP + MySQL hoặc Spring Boot + MySQL.
